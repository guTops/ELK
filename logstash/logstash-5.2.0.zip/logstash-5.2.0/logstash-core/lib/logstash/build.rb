# encoding: utf-8
BUILD_INFO = {"build_date"=>"2017-01-24T20:13:39+00:00", "build_sha"=>"3159d88e5168023353de938ef6fa2aad0763d05f", "build_snapshot"=>false}